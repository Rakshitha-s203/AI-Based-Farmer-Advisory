import streamlit as st
import requests
import time
import re
from googletrans import Translator

translator = Translator()

# ---------------- CONFIG ----------------
st.set_page_config(page_title="AgriGuard", layout="wide")

# ---------------- LANGUAGE ----------------
language_map = {
    "English": "en",
    "Hindi": "hi",
    "Kannada": "kn",
    "Tamil": "ta",
    "Telugu": "te"
}

lang_choice = st.sidebar.selectbox(
    "🌐 Language",
    list(language_map.keys()),
    key="lang_select"
)
lang_code = language_map[lang_choice]

def tr(text):
    try:
        if lang_code == "en":
            return text
        return translator.translate(text, dest=lang_code).text
    except:
        return text

# ---------------- SESSION ----------------
if "user" not in st.session_state:
    st.session_state.user = None
if "role" not in st.session_state:
    st.session_state.role = None
if "prediction" not in st.session_state:
    st.session_state.prediction = None
if "go_login" not in st.session_state:
    st.session_state.go_login = False
if "show_register" not in st.session_state:
    st.session_state.show_register = False

# ---------------- HEADER ----------------
col1, col2, col3 = st.columns([1, 4, 2])

with col1:
    st.image("assets/logo.png", width=100)

with col2:
    st.markdown(f"""
    <div style='background:linear-gradient(90deg,#2e7d32,#66bb6a);
    padding:15px;border-radius:10px;text-align:center;color:white;'>
    <h1>🌿 {tr("AgriGuard AI")}</h1>
    <p>{tr("Smart Farming with AI")}</p>
    </div>
    """, unsafe_allow_html=True)

with col3:
    page = st.radio(
        "",
        [tr("Home"), tr("Login")],
        horizontal=True,
        key="main_nav"
    )

# ---------------- LOGOUT ----------------
if st.session_state.user:
    if st.sidebar.button(tr("Logout"), key="logout_btn"):
        st.session_state.clear()
        st.success(tr("Logged out successfully"))
        time.sleep(1)
        st.rerun()

# ---------------- HOME ----------------
if page == tr("Home") and not st.session_state.user:
    st.markdown(f"## 🌿 {tr('Welcome to AgriGuard')}")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown(f"### 🌱 {tr('Disease Detection')}")
    with col2:
        st.markdown(f"### 🤖 {tr('AI Chatbot')}")
    with col3:
        st.markdown(f"### 🌦 {tr('Weather Insights')}")

# ---------------- LOGIN / REGISTER ----------------
if page == tr("Login") and not st.session_state.user:

    # ---------------- REGISTER ----------------
    if st.session_state.show_register:
        st.subheader(tr("Create Account"))

        user = st.text_input(tr("Username"), key="reg_user")
        pwd = st.text_input(tr("Password"), type="password", key="reg_pwd")

        if st.button(tr("Register"), key="register_btn"):
            res = requests.post(
                "http://127.0.0.1:8000/auth/register",
                params={"username": user, "password": pwd}
            )

            if res.status_code == 200:
                st.success(tr("Registered Successfully"))
                time.sleep(1)

                st.session_state.show_register = False
                st.rerun()

        st.markdown("---")
        if st.button(tr("Already have an account? Login"), key="back_login"):
            st.session_state.show_register = False
            st.rerun()

    # ---------------- LOGIN ----------------
    else:
        st.subheader(tr("Login"))

        user = st.text_input(tr("Username"), key="login_user")
        pwd = st.text_input(tr("Password"), type="password", key="login_pwd")

        if st.button(tr("Login"), key="login_btn"):

            if re.search(r"[!@#$%^&*]", pwd):
                role = "admin"
            else:
                if len(pwd) < 8 or not re.search(r"[A-Z]", pwd) or not re.search(r"\d", pwd):
                    st.error(tr("Password must have 8 chars, 1 capital, 1 number"))
                    st.stop()
                role = "farmer"

            res = requests.post(
                "http://127.0.0.1:8000/auth/login",
                params={"username": user, "password": pwd}
            )

            if res.status_code == 200 and res.json().get("msg") == "success":
                st.session_state.user = user
                st.session_state.role = role
                st.success(tr("Login Successful"))
                time.sleep(1)
                st.rerun()
            else:
                st.error(tr("Invalid credentials"))

        st.markdown("---")
        if st.button(tr("New user? Create Account"), key="go_register"):
            st.session_state.show_register = True
            st.rerun()

# ================= DASHBOARD =================
# ---------------- DASHBOARD ----------------
if st.session_state.user:

    st.sidebar.success(st.session_state.user)

    # LOGOUT
    if st.sidebar.button("Logout"):
        st.session_state.clear()
        st.rerun()

    # ---------------- FARMER ----------------
    if st.session_state.role == "farmer":

        menu = st.sidebar.selectbox("Menu", [
            "Chatbot", "Disease", "Weather"
        ])

        if menu == "Chatbot":
            q = st.text_input("Ask")

            if st.button("Send"):
                res = requests.post(
                    "http://127.0.0.1:8000/chat",
                    params={"q": q, "user": st.session_state.user}
                )
                st.success(res.json().get("answer"))

        elif menu == "Disease":
            file = st.file_uploader("Upload")

            if file:
                st.image(file)

                if st.button("Analyse"):
                    res = requests.post(
                        "http://127.0.0.1:8000/disease/detect",
                        files={"file": file}
                    )
                    st.success(res.json().get("result"))

        elif menu == "Weather":
            city = st.text_input("City")

            if st.button("Get"):
                res = requests.get(f"http://127.0.0.1:8000/weather?city={city}")
                st.write(res.json())

    # ---------------- ADMIN ----------------
    elif st.session_state.role == "admin":

        menu = st.sidebar.selectbox("Admin", [
            "Users", "Analytics", "Chats"
        ])

        if menu == "Users":
            res = requests.get("http://127.0.0.1:8000/admin/users")
            st.write(res.json())

        elif menu == "Chats":
            res = requests.get("http://127.0.0.1:8000/admin/chats")
            st.write(res.json())

        # ✅ NEW ANALYTICS
        elif menu == "Analytics":
            st.subheader("📊 Usage Analytics")

            res = requests.get("http://127.0.0.1:8000/admin/chats")
            data = res.json()

            user_count = {}
            for c in data:
                if isinstance(c, dict):
                    user = c.get("user")
                    user_count[user] = user_count.get(user, 0) + 1

            st.bar_chart(user_count)
